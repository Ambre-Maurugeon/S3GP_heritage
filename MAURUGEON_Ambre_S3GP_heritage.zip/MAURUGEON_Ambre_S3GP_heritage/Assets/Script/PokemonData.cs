using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PokemonData : BaseData
{
    [Serializable]
    public struct Stats{ //encapsuler données ds struct
        public int pv;
        public int atk;
        public int def;
        public int atkSpe;
        public int defSpe;
        public int speed;

        public Stats(int pv, int atk, int def, int atkSpe, int defSpe, int speed)
        {
            this.pv=pv;
            this.atk=atk;
            this.def=def;
            this.atkSpe=atkSpe;
            this.defSpe=defSpe;
            this.speed=speed;
        }

        public Stats(Stats statsBase, int coeff){

            pv = statsBase.pv *coeff;
            atk = statsBase.atk*coeff;
            def = statsBase.def*coeff;
            atkSpe = statsBase.atkSpe*coeff;
            defSpe = statsBase.defSpe*coeff;
            speed = statsBase.speed*coeff;
        }
    }
    public enum Type{
            Acier,
            Combat,
            Dragon,
            Eau,
            Electrique,
            Fée,
            Feu,
            Glace,
            Insecte,
            Normal,
            Plante,
            Poison,
            Psy,
            Roche,
            Sol,
            Spectre,
            Ténèbres,
            Vol
        } ;


    [Serializable]
    public struct Infos{
        
        public int idNumber;

        public string category;

        public float size;
        public float weight;

        public string caption;
        
        public Type[] strengths;
        public Type[] weaknesses;
        public int idPokeBase;

        public Infos(int idNumber, float size, float weight, string category, string caption, Type[] strengths, Type[] weaknesses, int idPokeBase)
        {
        this.idNumber=idNumber;
        this.size=size;
        this.weight=weight;
        this.category=category;
        this.caption=caption;
        this.strengths=strengths;
        this.weaknesses=weaknesses;
        this.idPokeBase=idPokeBase;
        }
    }
    
    [Serializable]
    public struct AttackWrapper{
        public string label;
        public int level;

        public AttackWrapper(string label, int level){
            this.label = label;
            this.level = level;
        }
    }

    public string name; //y'a plus ca normalement
    public Sprite icon;

    public Infos info;
    public Stats statsBase;

    public List<AttackWrapper> attacks = new();

    public PokemonData(string label, Sprite icon, string caption, Infos info, Stats statsBase): base(label, caption)
    {
        this.info=info;
        this.icon=icon;
        this.statsBase = statsBase; //ici = stats et Stats stats si ca marche aps
    }

    
    public Stats GetStatsByLvl(int lvl, int evolutionStep)=>new(statsBase, (lvl * evolutionStep)/10);

    public override void DisplayName(){
        Debug.Log("Pokemon :" + label);
    }

}
