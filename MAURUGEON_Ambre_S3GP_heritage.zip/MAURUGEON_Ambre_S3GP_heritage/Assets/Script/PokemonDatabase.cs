using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CreateAssetMenu(fileName = "Pokemon", menuName= "Database/Pokemon", order = 0)]
public class PokemonDatabase : ScriptableObject
{
    public List<PokemonData> datas = new();

    public void InitData(){
        datas.RemoveAll(data=>data.info.idNumber<=0);
    }
    public void CreateData(){
        if(!datas.Exists(data => data.info.idNumber==3))
        {
            PokemonData.Infos info = new()
            {
                idNumber = 3,
                size = 2,
                weight = 100,
                category = "Graine",
                caption = "Ce Pokémon est capable de transformer la lumière du soleil en énergie. Il est donc encore plus fort en été",
                strengths=datas[0].info.strengths,
                weaknesses=datas[0].info.weaknesses,
                idPokeBase= datas[0].info.idNumber,
            };

            Sprite pokeIcon = (Sprite)AssetDatabase.LoadAssetAtPath($"Assets/Sprite/florizarre.png", typeof(Sprite));
            
            PokemonData pokeData = new(
            label : "Florizarre",
            icon : pokeIcon,
            info : info,
            caption : "Ce Pokémon est capable de transformer la lumière du soleil en énergie. Il est donc encore plus fort en été",
            statsBase : default);
            pokeData.statsBase = pokeData.GetStatsByLvl(40,3);

            datas.Add(pokeData);
        } 
    }
}
