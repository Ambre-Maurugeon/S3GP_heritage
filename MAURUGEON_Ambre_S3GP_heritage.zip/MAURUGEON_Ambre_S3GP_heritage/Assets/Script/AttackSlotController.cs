using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;


public class AttackSlotController : MonoBehaviour
{ //sur chaque bouton
    public Text _txtLabel;
    [SerializeField] private Button _btnAtk;

    [HideInInspector]
    public AttackData data;

    private FightPokemon _fightPokemon;
    
    //Attaque Data
    private float _puissance;
    private float _precision;

    // Accesseurs get pour puissance et précision
    public float Puissance => _puissance;
    public float Precision => _precision;


    //instance
    
    public static AttackSlotController instance;

    private void Awake(){
        _btnAtk = GetComponent<Button>();
        _txtLabel = _btnAtk.GetComponentInChildren<Text>();

        //_btnAtk.onClick.AddListener(() => DisplayAttack());

        _fightPokemon = FindObjectOfType<FightPokemon>();
    }       


    public void Init(string label)
    {
        data = DatabaseManager.GetInstance().GetAttackData(label);
        _txtLabel.text = data.label;
        //Debug.Log (data.label +data.puissance);
    }

    // Si Btn click
    public void ChoosenAttack()
    {
        Debug.Log("Notre Pokemon attaque avec " + _txtLabel.text + ".");
        data = DatabaseManager.GetInstance().GetAttackData(_txtLabel.text);
        _puissance = data.puissance;
        _precision = data.precision;
        instance = this; 
        _fightPokemon.StartCoroutine(_fightPokemon.AttackOpponent());
    }


     // private void DisplayAttack(){
    //     Debug.Log($"{BattleController.CurrentPokemon._data.label} utilise {_txtLabel.text}");
    // }

}


