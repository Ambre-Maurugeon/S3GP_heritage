using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class FightPokemon : MonoBehaviour
{
    //Pokemon
    [SerializeField] private PokemonDatabase pokemonDatabase;

    public PokemonData monPokemon;
    private PokemonData copyMonPokemon;
    [SerializeField] private int ActualHealth;
    [SerializeField] private int Stat;
    
    public PokemonData PokemonOpponent;
    private PokemonData copyPokemonOpponent;


    //private PokemonData[] Players;
    private bool CanCheck;  

    [SerializeField] private bool MyPokemonIsWeak=false;
    [SerializeField] private bool OpponentIsWeak=false;

    // Random
    private int index;  //rdm opponent
    private int unluck ; //savoir si le lancé a reussi 
    private System.Random rdm = new System.Random();

    //UI
    [SerializeField] private Image Img_monPokemon;
    [SerializeField] private Image Img_Opponent;
    [SerializeField] private Text text;
    [SerializeField] private Text _monPokPV;
    [SerializeField] private Text _opponentPV;
    [SerializeField] private GameObject attacks;

    //Attack Data
    private float puissance;
    private float precision;

    private int degats ;
    private int rounds=1;
    
    void Awake(){
        index = rdm.Next(0, pokemonDatabase.datas.Count);
        text = text.GetComponent<Text>();
        _monPokPV = _monPokPV.GetComponent<Text>();
        _opponentPV = _opponentPV.GetComponent<Text>();
        attacks.SetActive(false);
    }

    void Start()
    {   
        //Récupérer les 2 adversaires
        PokemonInfoController infoController = FindObjectOfType<PokemonInfoController>();
        monPokemon = infoController.GetMyPokemon();
        PokemonOpponent = infoController.GetOpponent(index);

        // Copier les pokemon pr pas toucher à la database
        copyMonPokemon = new PokemonData(monPokemon.label, monPokemon.icon, monPokemon.caption, monPokemon.info, monPokemon.statsBase);
        copyPokemonOpponent = new PokemonData(PokemonOpponent.label, PokemonOpponent.icon, PokemonOpponent.caption, PokemonOpponent.info, PokemonOpponent.statsBase);

        Img_monPokemon.sprite=copyMonPokemon.icon;
        Img_Opponent.sprite=copyPokemonOpponent.icon;
        
        StartCoroutine(InitCurrentLife());
        _monPokPV.text = copyMonPokemon.statsBase.pv + "/" + monPokemon.statsBase.pv + " HP";
        _opponentPV.text = copyPokemonOpponent.statsBase.pv + "/" + PokemonOpponent.statsBase.pv + " HP";
        StartCoroutine(InitStatsPoints());

        Debug.Log("Les deux opposants sont " + monPokemon.label + " et " + PokemonOpponent.label + ".");
        text.text = monPokemon.label + " s'oppose à " + PokemonOpponent.label + ".";
        Debug.Log(monPokemon.label + ", notre Pokemon, commence avec " + monPokemon.statsBase.pv + " pv. Et l'ennemi débute avec " + PokemonOpponent.statsBase.pv + " pv.");

        StartCoroutine(IsMyPokemonWeak());
    }

    // Update is called once per frame
    void Update()
    {
        isPokemonAlive();
    }

    IEnumerator InitCurrentLife(){
        yield return new WaitForSeconds(0.1f);
        ActualHealth = monPokemon.statsBase.pv;
    }

    IEnumerator InitStatsPoints(){
        yield return new WaitForSeconds(0.1f);
        Stat = ActualHealth + monPokemon.statsBase.atk + monPokemon.statsBase.def;
    }

    void isPokemonAlive(){
        if(copyMonPokemon.statsBase.pv > 0 && copyPokemonOpponent.statsBase.pv > 0 && CanCheck){
            Debug.Log("Le combat continue, les adversaires sont toujours en vie.");
        }  
        CanCheck=false;
    }

    //Check si My Pokemon is weak against Opponent
    IEnumerator IsMyPokemonWeak()
    {
        bool weaknessFound = false;

        // Check si mon pokemon est faible
        for (int j = 0; j < PokemonOpponent.info.strengths.Length; j++)
        {
            for (int i = 0; i < monPokemon.info.weaknesses.Length; i++)
            {
                if (PokemonOpponent.info.strengths[j] == monPokemon.info.weaknesses[i])
                {
                    MyPokemonIsWeak = true;
                    weaknessFound = true;

                    yield return new WaitForSeconds(1.8f);
                    Debug.Log("L'ennemi a un type fort face à notre pokemon.");
                    text.text = "L'ennemi a un type fort face à notre pokemon.";

                    break;
                }
            }
            if (weaknessFound) break;
        }

        // l'ennemi n'a pas l'ascendant
        if (!weaknessFound)
        {
            for (int j = 0; j < monPokemon.info.strengths.Length; j++)
            {
                for (int i = 0; i < PokemonOpponent.info.weaknesses.Length; i++)
                {
                    if (monPokemon.info.strengths[j] == PokemonOpponent.info.weaknesses[i])
                    {
                        OpponentIsWeak = true;
                        weaknessFound = true;

                        yield return new WaitForSeconds(1.8f);
                        Debug.Log("Notre Pokemon a un type fort face à l'ennemi.");
                        text.text = "Notre Pokemon a un type fort face à l'ennemi.";

                        break;
                    }
                }
                if (weaknessFound) break;
            }
        }
        // personne n'a l'ascendant
        if (!weaknessFound)
        {
            yield return new WaitForSeconds(1.8f);
            Debug.Log("Le combat s'annonce croustillant, aucun pokemon n'a l'ascendant de par son type.");
            text.text = "Le combat est équilibré.";
        }

        yield return new WaitForSeconds(1.8f);
        text.text = "Round n°" + rounds;
        yield return new WaitForSeconds(1.8f);
        text.text = "Attaquez l'ennemi !";
        attacks.SetActive(true);
    }


    //Mon Pokemon Attaque
    public IEnumerator AttackOpponent(){
        text.text = "Notre Pokemon attaque avec <color=blue>" + AttackSlotController.instance._txtLabel.text + "</color>.";
        attacks.SetActive(false);
        yield return new WaitForSeconds(1.8f);

        //Récupérer la data attaque en fonction du bouton cliqué
        puissance = AttackSlotController.instance.Puissance;
        precision = AttackSlotController.instance.Precision;
        Debug.Log("La puissance de l'attaque de notre pokemon s'élève a " + puissance + " et sa précision à " + precision*100 + "%");
        
        unluck = rdm.Next(0,101);
        //Coup réussi
        if (unluck < precision*100) {
            GetDegats();
            if (MyPokemonIsWeak)
            {
                copyPokemonOpponent.statsBase.pv -= degats/ 2;  
                
                Debug.Log(copyMonPokemon.label + " a seulement subi " + degats / 2 + " de dégats.");
                text.text = copyMonPokemon.label + " a seulement subi <color=red>" + degats / 2 + "</color> de dégats.";
            }
            else if (OpponentIsWeak)
            {
                copyPokemonOpponent.statsBase.pv -= degats * 2;
                
                Debug.Log(copyMonPokemon.label + " a infligé " + degats * 2 + " dégats à "  + copyPokemonOpponent.label + ".") ;
                text.text = copyMonPokemon.label + " a infligé <color=red>" + degats * 2 + "</color> dégats à "  + copyPokemonOpponent.label + ".";
            }
            else
            {
                copyPokemonOpponent.statsBase.pv -= degats;
                
                Debug.Log(copyMonPokemon.label  + " a infligé " + degats + " de dégats.");
                text.text = copyMonPokemon.label  + " a infligé <color=red>" + degats + "</color> de dégats.";
            }
            //Init PV
            if(copyPokemonOpponent.statsBase.pv<0){
                copyPokemonOpponent.statsBase.pv=0;
            }
            _opponentPV.text = copyPokemonOpponent.statsBase.pv + "/" + PokemonOpponent.statsBase.pv + " HP";
            
            yield return new WaitForSeconds(1.8f);
        }
        //Coup raté
        else {
            Debug.Log("<color=red> Coup raté ! </color>");
            yield return new WaitForSeconds(1.8f);
        }
        CanCheck = true;
        if (copyPokemonOpponent.statsBase.pv <= 0)
        {
            Debug.Log(copyPokemonOpponent.label + " est décédé.");
            text.text = "<size=14>" + copyPokemonOpponent.label + " est décédé en " + rounds + "round.s.\n<color=green>Notre " + copyMonPokemon.label + " a gagné.</color></size>";
            
            attacks.SetActive(false);
        }
        else
        {
            Debug.Log(copyPokemonOpponent.label + " est à " + copyPokemonOpponent.statsBase.pv + " hp.");
            text.text = copyPokemonOpponent.label + " est à <color=green>" + copyPokemonOpponent.statsBase.pv + " hp</color>.";
            StartCoroutine(TakeDamage());
        }
    }

    //Get Degat
    void GetDegats(){
        degats = (int)Math.Ceiling((puissance /100) * copyMonPokemon.statsBase.atk);
        //Debug.Log("L'attaque de mon pokemon est estimée à " + degats);
    }

    private AttackData _data;
    IEnumerator TakeDamage(){
        //Recup une attaque au hasard de mon Opponent
        int index = rdm.Next(0,4);
        yield return new WaitForSeconds(1.8f); 
        Debug.Log ("L'ennemi attaque avec " + PokemonOpponent.attacks[index].label);
        text.text = "L'ennemi attaque avec <color=blue>" + PokemonOpponent.attacks[index].label + "</color>.";
        yield return new WaitForSeconds(1.8f);
        
        _data = DatabaseManager.GetInstance().GetAttackData(PokemonOpponent.attacks[index].label);
        float _opponentPuissance = _data.puissance;
        float _opponentPrecision = _data.precision;
        Debug.Log ("L'attaque a une puissance de " + _opponentPuissance + " et une précision de " + _opponentPrecision*100 + "%");

        unluck = rdm.Next(0,101);

        //Coup réussi
        if (unluck < _opponentPrecision*100) {

            //A la place du GetDegats
            int degats = (int)Math.Ceiling((puissance /100) * copyPokemonOpponent.statsBase.atk); 
            //ceiling pr ne pas avoir d'attaque à 0

            if (MyPokemonIsWeak)
            {
                copyMonPokemon.statsBase.pv -= degats* 2;  
                Debug.Log(copyPokemonOpponent.label + " a infligé " + degats * 2 + " de dégats à " + copyMonPokemon.label);
                if(copyMonPokemon.statsBase.pv<0){
                    copyMonPokemon.statsBase.pv=0;
                }
                text.text = copyPokemonOpponent.label + " a infligé <color=red>" + degats * 2 + "</color> de dégats à " + copyMonPokemon.label ;
                _monPokPV.text = copyMonPokemon.statsBase.pv + "/" + monPokemon.statsBase.pv + " HP";
                yield return new WaitForSeconds(1.8f);
            }
            else if (OpponentIsWeak)
            {
                copyMonPokemon.statsBase.pv -= degats / 2;
                if(copyMonPokemon.statsBase.pv<0){
                    copyMonPokemon.statsBase.pv=0;
                }

                Debug.Log(copyMonPokemon.label + " a seulement subi " + degats / 2 + " dégats.");
                text.text = copyMonPokemon.label + " a seulement subi <color=red>" + degats / 2 + "</color> dégats.";
                _monPokPV.text = copyMonPokemon.statsBase.pv + "/" + monPokemon.statsBase.pv + " HP";
                
                yield return new WaitForSeconds(1.8f);
            }
            else
            {
                copyMonPokemon.statsBase.pv -= degats;
                if(copyMonPokemon.statsBase.pv<0){
                   copyMonPokemon.statsBase.pv=0;
                }

                Debug.Log(copyPokemonOpponent.label  + " a infligé " + degats + " de dégats.");
                text.text = copyPokemonOpponent.label  + " a infligé <color=red>" + degats + "</color> de dégats.";
                _monPokPV.text = copyMonPokemon.statsBase.pv + "/" + monPokemon.statsBase.pv + " HP";
                
                yield return new WaitForSeconds(1.8f);
            }
        }
        //Coup raté
        else {
            Debug.Log("Coup raté! Encore la faute à pas de chance !");
            text.text = "<color=red> Coup raté ! </color>";
            yield return new WaitForSeconds(1.8f);
        }

        CanCheck = true;

        if (copyMonPokemon.statsBase.pv <= 0)
        {
            Debug.Log(copyMonPokemon.label + " est décédé.");
            text.text = "<size=14>Notre " + copyMonPokemon.label + " est décédé en " + rounds + " round.s.\n<color=green>" + copyPokemonOpponent.label + " a gagné.</color></size>";
            
            attacks.SetActive(false);
        }
        else
        {
            Debug.Log(copyMonPokemon.label + " est à " + copyMonPokemon.statsBase.pv + " hp.");
            text.text = "Mon pokemon est à <color=green>" + copyMonPokemon.statsBase.pv + " hp</color>.";
            yield return new WaitForSeconds(1.8f);
            rounds+=1;
            text.text = "Round n°" + rounds;
            yield return new WaitForSeconds(1.8f);
            text.text= "Lancez votre attaque !" ;
            attacks.SetActive(true);
        }
    }

    
    // //2 fonctions (TakeDamage() et AttackOpponent()) en une
    // IEnumerator TakeDamage(){
    //     yield return new WaitForSeconds(0.1f);
    //     Debug.Log(monPokemon.label + ", notre Pokemon, commence avec " + monPokemon.statsBase.pv + " pv. Et l'ennemi débute avec " + PokemonOpponent.statsBase.pv + " pv.");

    //     PokemonData[] Players = {copyMonPokemon, copyPokemonOpponent};
        
    //     while (copyMonPokemon.statsBase.pv > 0 && copyPokemonOpponent.statsBase.pv > 0 )
    //     {
    //         for (int i=0; i<2;i++){
    //             if(Players[i].statsBase.pv > 0){
    //                 if (MyPokemonIsWeak)
    //                 {
    //                     Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk * 2;  
    //                     Debug.Log(Players[Math.Abs(i-1)].label + " a infligé " + Players[Math.Abs(i-1)].statsBase.atk * 2 + " de dégats à " + Players[i].label);
    //                     if(Players[i].statsBase.pv<0){
    //                         Players[i].statsBase.pv=0;
    //                     }
    //                 }
    //                 else if (OpponentIsWeak)
    //                 {
    //                     Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk / 2;
    //                     if(Players[i].statsBase.pv<0){
    //                         Players[i].statsBase.pv=0;
    //                     }
    //                     Debug.Log(Players[i].label + " a seulement subi " + Players[Math.Abs(i-1)].statsBase.atk / 2 + " dégats.");
    //                 }
    //                 else
    //                 {
    //                     Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk;
    //                     if(Players[i].statsBase.pv<0){
    //                         Players[i].statsBase.pv=0;
    //                     }
    //                     Debug.Log(Players[Math.Abs(i-1)].label  + " a infligé " + Players[Math.Abs(i-1)].statsBase.atk + " de dégats.");
    //                 }
    //                 CanCheck = true;

    //                 if (Players[i].statsBase.pv <= 0)
    //                 {
    //                     Debug.Log(Players[i].label + " est décédé.");
    //                     text.text = Players[i].label + " est décédé.\n<color=green>" + Players[Math.Abs(i-1)].label + " a gagné.</color>";
    //                     yield break;
    //                 }
    //                 else
    //                 {
    //                     Debug.Log(Players[i].label + " se retrouve à " + Players[i].statsBase.pv + " hp.");
    //                     yield return new WaitForSeconds(0.5f);
    //                 }
    //             }
    //         }    
    //     }
    // }
}
