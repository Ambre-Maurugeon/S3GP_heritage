using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleController : MonoBehaviour
{
    public PokemonController pokemon;
    public PokemonController pokemonCPU;

    public static PokemonController CurrentPokemon;

    // Start is called before the first frame update
    void Start()
    {
        pokemon.Init(DatabaseManager.GetInstance().database.datas[0]); //pokemon.Init(DatabaseManager.GetInstance().database.datas[0])
        pokemonCPU.Init(DatabaseManager.GetInstance().database.datas[0]); //pareil

        CurrentPokemon = pokemon;
    }
}
