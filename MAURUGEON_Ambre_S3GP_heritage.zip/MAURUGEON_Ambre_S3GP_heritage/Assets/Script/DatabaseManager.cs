using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DatabaseManager : MonoBehaviour
{
    private static DatabaseManager instance;

    public PokemonDatabase database;
    public AttackDatabase attackDatabase;

    public PokemonData GetData(int id) => database.datas[id]; //=> à la place accolades/return

    //Recup dans AttackDatabase les data de mon attaque GetAttackData(label attaque)
    public AttackData GetAttackData(string label){
        return attackDatabase?.datas.Find(x => x.label.ToLower().Contains(label.ToLower()));
    }

    private void Update()
        { //j'ai add private
            database.InitData();
            database.CreateData();
        }

    public static DatabaseManager GetInstance(){
        if(instance == null)
            instance = FindObjectOfType<DatabaseManager>();

        return instance; 
    }
}
    