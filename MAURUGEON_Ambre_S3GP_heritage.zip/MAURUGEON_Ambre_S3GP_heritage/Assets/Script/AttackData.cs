using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class AttackData : BaseData
{
    public enum CATEGORIES{
        PHYSICAL,
        SPECIAL,
        STATUT
    }

    public CATEGORIES category = CATEGORIES.PHYSICAL;
    public PokemonData.Type types; 
    public float puissance;
    
    [Range (0,1)]
    public float precision;

    public AttackData(string label, string caption) : base(label, caption){
        
    }

    public override void DisplayName(){
        Debug.Log("Attack : " + label);
        base.DisplayName();
    }

    public void InitID(){
       // id = 
    }
}
